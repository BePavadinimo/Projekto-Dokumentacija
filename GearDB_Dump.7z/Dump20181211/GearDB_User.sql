-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 88.222.190.242    Database: GearDB
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `User` (
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `Email` varchar(255) NOT NULL,
  `Birthday` datetime DEFAULT NULL,
  `Blocked` smallint(6) NOT NULL,
  `Country_Code` int(11) NOT NULL,
  `Rank_Name` varchar(45) NOT NULL,
  PRIMARY KEY (`Username`),
  KEY `fk_User_Country1_idx` (`Country_Code`),
  KEY `fk_User_Rank1_idx` (`Rank_Name`),
  CONSTRAINT `fk_User_Country1` FOREIGN KEY (`Country_Code`) REFERENCES `country` (`code`),
  CONSTRAINT `fk_User_Rank1` FOREIGN KEY (`Rank_Name`) REFERENCES `rank` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('domban','123456',NULL,NULL,'domban@ktu.edu',NULL,0,440,'Creator'),('Gabrielius','12345',NULL,NULL,'ule2ss@yahoo.com','1997-05-30 00:00:00',0,504,'Creator'),('karolissto','123','karolis','stoncius','ltkarolissto@gmail.com','1111-11-11 00:00:00',0,44,'User'),('Labas','123','123','123','la@las.com','2018-12-12 00:00:00',0,50,'Creator'),('Tadas','12345',NULL,NULL,'tadas@gmail.com',NULL,0,440,'User'),('temp','123','temp','temp','temp@gmail.com','1212-12-12 00:00:00',0,10,'User');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11 16:37:53
