-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 88.222.190.242    Database: GearDB
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Game`
--

DROP TABLE IF EXISTS `Game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Game` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(1020) NOT NULL,
  `ShortDescription` varchar(255) NOT NULL,
  `Price` double NOT NULL,
  `ReleaseDate` datetime NOT NULL,
  `VersionBranch` varchar(50) NOT NULL,
  `VersionNumber` double NOT NULL,
  `Dir` varchar(255) NOT NULL,
  `TrailerURL` varchar(255) NOT NULL,
  `AgeRestriction` int(11) NOT NULL,
  `Available` tinyint(4) NOT NULL,
  `Developer_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_Game_Developer1_idx` (`Developer_Id`),
  CONSTRAINT `fk_Game_Developer1` FOREIGN KEY (`Developer_Id`) REFERENCES `developer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Game`
--

LOCK TABLES `Game` WRITE;
/*!40000 ALTER TABLE `Game` DISABLE KEYS */;
INSERT INTO `Game` VALUES (1,'The Witcher 3: Wild Hunt','Experience the epic conclusion to the story of professional monster slayer, witcher Geralt of Rivia. As war rages on throughout the Northern Realms, you take on the greatest contract of your life — tracking down the Child of Prophecy, a living weapon that can alter the shape of the world.','Experience the epic conclusion to the story of professional monster slayer, witcher Geralt of Rivia. ',29.99,'2015-05-18 00:00:00','Relesed',1.13,'WITCHER3','https://www.youtube.com/watch?v=XHrskkHf958&t',14,1,1),(2,'Monster Hunter World','Welcome to a new world! In Monster Hunter: World, the latest installment in the series, you can enjoy the ultimate hunting experience, using everything at your disposal to hunt monsters in a new world teeming with surprises and excitement.','Welcome to a new world!',59.99,'2018-08-09 00:00:00','Relesed',1,'MONSTERHUNTERWORLD','https://www.youtube.com/watch?v=iNmegyyecu0',15,1,2),(3,'Assassin\'s Creed Odyssey','Choose your fate in Assassin\'s Creed® Odyssey. From outcast to living legend, embark on an odyssey to uncover the secrets of your past and change the fate of Ancient Greece.','Choose your fate in Assassin\'s Creed® Odyssey. ',59.99,'2018-10-05 00:00:00','Relesed',1.2,'ASSASINSCREEDODYSSEY','https://www.youtube.com/watch?v=s_SJZSAtLBA',18,1,3),(5,'sadasdas','asdasd','ner',66,'2018-07-25 00:00:00','sadasd',1,'33826515_1914298831928162_924781144015110144_n.jpg','sadas',0,1,25);
/*!40000 ALTER TABLE `Game` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11 16:37:51
