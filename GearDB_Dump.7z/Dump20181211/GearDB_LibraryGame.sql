-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 88.222.190.242    Database: GearDB
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `LibraryGame`
--

DROP TABLE IF EXISTS `LibraryGame`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `LibraryGame` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CreateDate` datetime NOT NULL,
  `LastOpen` datetime DEFAULT NULL,
  `PlayTime` time DEFAULT NULL,
  `User_Username` varchar(50) NOT NULL,
  `Game_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_LibraryGame_User1_idx` (`User_Username`),
  KEY `fk_LibraryGame_Game1_idx` (`Game_Id`),
  CONSTRAINT `fk_LibraryGame_Game1` FOREIGN KEY (`Game_Id`) REFERENCES `game` (`id`),
  CONSTRAINT `fk_LibraryGame_User1` FOREIGN KEY (`User_Username`) REFERENCES `user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LibraryGame`
--

LOCK TABLES `LibraryGame` WRITE;
/*!40000 ALTER TABLE `LibraryGame` DISABLE KEYS */;
INSERT INTO `LibraryGame` VALUES (1,'2018-12-10 00:00:00',NULL,'10:00:00','domban',1),(2,'2018-12-10 00:00:00',NULL,'20:00:00','domban',2);
/*!40000 ALTER TABLE `LibraryGame` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11 16:37:36
