-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 88.222.190.242    Database: GearDB
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comment`
--

DROP TABLE IF EXISTS `Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Comment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CreateDate` datetime NOT NULL,
  `Content` varchar(255) NOT NULL,
  `Blocked` tinyint(4) NOT NULL,
  `Game_Id` int(11) NOT NULL,
  `User_Username` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_Comment_Game1_idx` (`Game_Id`),
  KEY `fk_Comment_User1_idx` (`User_Username`),
  CONSTRAINT `fk_Comment_Game1` FOREIGN KEY (`Game_Id`) REFERENCES `game` (`id`),
  CONSTRAINT `fk_Comment_User1` FOREIGN KEY (`User_Username`) REFERENCES `user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comment`
--

LOCK TABLES `Comment` WRITE;
/*!40000 ALTER TABLE `Comment` DISABLE KEYS */;
INSERT INTO `Comment` VALUES (1,'2018-12-09 16:35:55','good',0,1,'Gabrielius'),(2,'2018-12-09 16:36:56','nice',0,1,'Gabrielius'),(3,'2018-12-09 17:25:13','change rating',0,1,'Gabrielius'),(4,'2018-12-09 17:37:09','change rating 1.0',0,1,'Gabrielius'),(5,'2018-12-09 18:20:31','123',0,1,'domban'),(6,'2018-12-09 18:20:46','1234',0,1,'domban'),(7,'2018-12-09 18:53:51','change rating 2.0',0,1,'Gabrielius'),(8,'2018-12-09 18:56:16','change rating 2.0',0,1,'Gabrielius'),(9,'2018-12-09 19:02:10','change',0,1,'Gabrielius'),(10,'2018-12-09 19:02:14','change',0,1,'Gabrielius'),(11,'2018-12-09 19:04:18','it works?',0,1,'Gabrielius'),(12,'2018-12-10 13:52:12','HEhehe nulauziau Domanto acc\r\n',0,1,'domban'),(13,'2018-12-10 18:30:27','',0,1,'Gabrielius'),(14,'2018-12-10 18:31:11','',0,1,'Gabrielius'),(15,'2018-12-10 18:31:29','no rating',0,1,'Gabrielius'),(20,'2018-12-10 21:06:30','komentaras be reitingo ',0,1,'Tadas'),(21,'2018-12-11 12:17:19','komentaras123',0,1,'temp');
/*!40000 ALTER TABLE `Comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11 16:37:41
