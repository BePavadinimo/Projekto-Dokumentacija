-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 88.222.190.242    Database: GearDB
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Mark`
--

DROP TABLE IF EXISTS `Mark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Mark` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CreateDate` datetime NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `Game_Id` int(11) NOT NULL,
  `User_Username` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_Mark_Game1_idx` (`Game_Id`),
  KEY `fk_Mark_User1_idx` (`User_Username`),
  CONSTRAINT `fk_Mark_Game1` FOREIGN KEY (`Game_Id`) REFERENCES `game` (`id`),
  CONSTRAINT `fk_Mark_User1` FOREIGN KEY (`User_Username`) REFERENCES `user` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mark`
--

LOCK TABLES `Mark` WRITE;
/*!40000 ALTER TABLE `Mark` DISABLE KEYS */;
INSERT INTO `Mark` VALUES (1,'2018-12-09 12:47:08','nice',1,'Gabrielius'),(2,'2018-12-09 12:50:50','nice',1,'Gabrielius'),(3,'2018-12-09 13:11:05','neri nice?',1,'Gabrielius'),(4,'2018-12-09 13:13:57','1',1,'Gabrielius'),(5,'2018-12-09 13:21:09','2',1,'Gabrielius'),(6,'2018-12-09 13:23:14','3',1,'Gabrielius'),(7,'2018-12-09 13:30:34','neet',1,'Gabrielius'),(8,'2018-12-09 13:39:18','neet',1,'Gabrielius'),(9,'2018-12-09 14:02:33','null',1,'Gabrielius'),(10,'2018-12-09 14:03:18','12',1,'Gabrielius'),(11,'2018-12-09 14:03:46','4',3,'Gabrielius'),(12,'2018-12-09 14:06:15','null',1,'Gabrielius'),(13,'2018-12-09 14:06:30','null',1,'Gabrielius'),(14,'2018-12-09 14:06:59','123',1,'Gabrielius'),(15,'2018-12-09 14:10:08',NULL,1,'Gabrielius'),(16,'2018-12-09 14:54:22',NULL,1,'Gabrielius'),(17,'2018-12-09 14:57:34',NULL,1,'Gabrielius'),(18,'2018-12-09 14:59:31','456',3,'Gabrielius'),(19,'2018-12-09 15:02:33','it\'s alive',2,'Gabrielius'),(20,'2018-12-09 15:04:33','it\'s alive 2.0',1,'Gabrielius'),(21,'2018-12-09 15:06:33','it\'s alive 3.0',1,'Gabrielius'),(22,'2018-12-09 15:07:36','it\'s alive 4.0',1,'Gabrielius'),(23,'2018-12-09 15:09:21','it\'s alive 5.0',1,'Gabrielius'),(24,'2018-12-09 15:11:39','it\'s alive 6.0',1,'Gabrielius'),(25,'2018-12-09 15:13:40','it\'s alive 7.0',1,'Gabrielius'),(26,'2018-12-09 15:19:19','it\'s alive 8.0',1,'Gabrielius'),(27,'2018-12-09 18:20:00','cool',1,'domban'),(28,'2018-12-10 21:03:17','cool',1,'Tadas'),(29,'2018-12-10 21:33:24','',3,'Tadas'),(30,'2018-12-10 21:34:02','this is a note',3,'Tadas'),(31,'2018-12-11 12:17:04','note123',1,'temp');
/*!40000 ALTER TABLE `Mark` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11 16:37:30
